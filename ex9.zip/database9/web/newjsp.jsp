<%@ page import="java.sql.*" %>
<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>

<%
String name = request.getParameter("name");
String email = request.getParameter("email");
String category = request.getParameter("category");
String unitSize = request.getParameter("unitSize");
String unitPrice = request.getParameter("unitPrice");

if (name != null && email != null && category != null
        && unitSize != null && unitPrice != null) {

    try {

        Class.forName("com.mysql.cj.jdbc.Driver");

        Connection con = DriverManager.getConnection(
            "jdbc:mysql://localhost:3306/sportsdb",
            "root",
            "Shichan!5"
        );

        String sql = "INSERT INTO orders " +
                     "(name, email, category, unit_size, unit_price) " +
                     "VALUES (?, ?, ?, ?, ?)";

        PreparedStatement ps = con.prepareStatement(sql);

        ps.setString(1, name);
        ps.setString(2, email);
        ps.setString(3, category);
        ps.setInt(4, Integer.parseInt(unitSize));
        ps.setDouble(5, Double.parseDouble(unitPrice));

        ps.executeUpdate();

        ps.close();
        con.close();

        response.sendRedirect("order.jsp");
        return;

    } catch (Exception e) {

        out.println(
            "<div class='error'>" +
            "Database Error: " + e.getMessage() +
            "</div>"
        );
    }
}
%>

<!DOCTYPE html>
<html>

<head>

    <meta charset="UTF-8">

    <title>Online Shopping</title>

    <style>

        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            font-family: Arial, sans-serif;
            background: linear-gradient(135deg, #667eea, #764ba2);
            min-height: 100vh;

            display: flex;
            justify-content: center;
            align-items: center;

            padding: 30px;
        }

        .container {
            width: 480px;
            background: white;
            padding: 35px;
            border-radius: 15px;

            box-shadow:
                0 10px 35px rgba(0,0,0,0.3);
        }

        .logo {
            text-align: center;
            font-size: 35px;
            font-weight: bold;
            color: #667eea;
            margin-bottom: 5px;
        }

        h1 {
            text-align: center;
            color: #333;
            margin: 5px 0;
        }

        .subtitle {
            text-align: center;
            color: #777;
            margin-bottom: 25px;
        }

        label {
            display: block;
            margin-top: 15px;
            margin-bottom: 6px;
            font-weight: bold;
            color: #333;
        }

        input,
        select {
            width: 100%;
            padding: 12px;

            border: 1px solid #ccc;
            border-radius: 7px;

            font-size: 15px;
            outline: none;
        }

        input:focus,
        select:focus {
            border-color: #667eea;
        }

        .total {
            margin-top: 20px;
            padding: 15px;

            background: #f1f3ff;

            border-radius: 8px;

            text-align: center;

            font-size: 20px;
            font-weight: bold;

            color: #4b4b4b;
        }

        button {
            width: 100%;

            margin-top: 20px;

            padding: 14px;

            border: none;
            border-radius: 7px;

            background: #667eea;

            color: white;

            font-size: 17px;
            font-weight: bold;

            cursor: pointer;
        }

        button:hover {
            background: #5568d9;
        }

        .back {
            display: block;

            text-align: center;

            margin-top: 18px;

            color: #555;

            text-decoration: none;
        }

        .back:hover {
            text-decoration: underline;
        }

        .error {
            background: #ffe6e6;

            color: red;

            padding: 12px;

            text-align: center;

            margin-bottom: 15px;

            border-radius: 7px;
        }

    </style>

    <script>

        function calculateTotal() {

            let quantity =
                parseFloat(
                    document.getElementById("unitSize").value
                ) || 0;

            let price =
                parseFloat(
                    document.getElementById("unitPrice").value
                ) || 0;

            let total = quantity * price;

            document.getElementById("total").innerHTML =
                "Total Amount: &#8377;" +
                total.toFixed(2);
        }

    </script>

</head>

<body>

<div class="container">

    <div class="logo">
        ONLINE SHOP
    </div>

    <h1>Online Shopping</h1>

    <div class="subtitle">
        Place Your Order
    </div>

    <form method="post">

        <label>Customer Name</label>

        <input
            type="text"
            name="name"
            placeholder="Enter your name"
            required
        >

        <label>Email Address</label>

        <input
            type="email"
            name="email"
            placeholder="Enter your email"
            required
        >

        <label>Product Category</label>

        <select name="category" required>

            <option value="">
                -- Select Category --
            </option>

            <option value="Electronics">
                Electronics
            </option>

            <option value="Clothing">
                Clothing
            </option>

            <option value="Footwear">
                Footwear
            </option>

            <option value="Home Appliances">
                Home Appliances
            </option>

            <option value="Mobile Phones">
                Mobile Phones
            </option>

            <option value="Laptops">
                Laptops
            </option>

            <option value="Accessories">
                Accessories
            </option>

            <option value="Books">
                Books
            </option>

        </select>

        <label>Quantity</label>

        <input
            type="number"
            id="unitSize"
            name="unitSize"
            min="1"
            placeholder="Enter quantity"
            oninput="calculateTotal()"
            required
        >

        <label>Price Per Unit (&#8377;)</label>

        <input
            type="number"
            id="unitPrice"
            name="unitPrice"
            min="0"
            step="0.01"
            placeholder="Enter product price"
            oninput="calculateTotal()"
            required
        >

        <div class="total" id="total">
            Total Amount: &#8377;0.00
        </div>

        <button type="submit">
            Place Order
        </button>

    </form>

    <a href="index.jsp" class="back">
        Back to Home
    </a>

</div>

</body>

</html>