<%@ page import="java.sql.*" %>

<!DOCTYPE html>
<html>

<head>

    <meta charset="UTF-8">

    <title>Online Shopping - Order Details</title>

    <style>

        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            padding: 40px;
            font-family: Arial, sans-serif;
            background: linear-gradient(135deg, #667eea, #764ba2);
            min-height: 100vh;
        }

        .container {
            width: 95%;
            max-width: 1200px;
            margin: auto;
            background: white;
            padding: 30px;
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.4);
        }

        h1 {
            text-align: center;
            color: #333;
            margin-bottom: 5px;
        }

        .subtitle {
            text-align: center;
            color: #777;
            margin-bottom: 25px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        th {
            background: #667eea;
            color: white;
            padding: 14px;
            border: 1px solid #5568d9;
        }

        td {
            padding: 12px;
            text-align: center;
            border: 1px solid #ddd;
        }

        tr:nth-child(even) {
            background-color: #f7f7ff;
        }

        tr:hover {
            background-color: #eeeeff;
        }

        .price {
            font-weight: bold;
        }

        .total {
            font-weight: bold;
            color: #667eea;
        }

        .message {
            text-align: center;
            padding: 20px;
            color: #777;
        }

        .error {
            color: red;
            text-align: center;
            padding: 15px;
        }

        .button-area {
            text-align: center;
            margin-top: 25px;
        }

        .button {
            display: inline-block;
            padding: 12px 25px;
            background: #667eea;
            color: white;
            text-decoration: none;
            border-radius: 7px;
            margin: 5px;
        }

        .button:hover {
            background: #5568d9;
        }

        .count {
            margin-top: 20px;
            text-align: right;
            font-weight: bold;
            color: #555;
        }

        @media (max-width: 800px) {

            body {
                padding: 15px;
            }

            .container {
                width: 100%;
                padding: 15px;
                overflow-x: auto;
            }

            table {
                min-width: 900px;
            }

        }

    </style>

</head>

<body>

<div class="container">

    <h1>Online Shopping</h1>

    <div class="subtitle">
        Customer Order Details
    </div>

<%

int orderCount = 0;

try {

    Class.forName("com.mysql.cj.jdbc.Driver");

    Connection con = DriverManager.getConnection(
        "jdbc:mysql://localhost:3306/sportsdb",
        "root",
        "Shichan!5"
    );

    String sql =
        "SELECT id, name, email, category, unit_size, unit_price " +
        "FROM orders ORDER BY id DESC";

    PreparedStatement ps = con.prepareStatement(sql);

    ResultSet rs = ps.executeQuery();

%>

    <table>

        <tr>
            <th>Order ID</th>
            <th>Customer Name</th>
            <th>Email</th>
            <th>Product Category</th>
            <th>Quantity</th>
            <th>Unit Price</th>
            <th>Total Amount</th>
        </tr>

<%

    while (rs.next()) {

        orderCount++;

        int id = rs.getInt("id");

        String name = rs.getString("name");

        String email = rs.getString("email");

        String category = rs.getString("category");

        int quantity = rs.getInt("unit_size");

        double unitPrice = rs.getDouble("unit_price");

        double totalPrice = quantity * unitPrice;

%>

        <tr>

            <td>
                <%= id %>
            </td>

            <td>
                <%= name %>
            </td>

            <td>
                <%= email %>
            </td>

            <td>
                <%= category %>
            </td>

            <td>
                <%= quantity %>
            </td>

            <td class="price">
                &#8377;<%= String.format("%.2f", unitPrice) %>
            </td>

            <td class="total">
                &#8377;<%= String.format("%.2f", totalPrice) %>
            </td>

        </tr>

<%

    }

    if (orderCount == 0) {

%>

        <tr>

            <td colspan="7" class="message">
                No orders found.
            </td>

        </tr>

<%

    }

    rs.close();

    ps.close();

    con.close();

} catch (Exception e) {

%>

        <tr>

            <td colspan="7" class="error">
                Database Error: <%= e.getMessage() %>
            </td>

        </tr>

<%

}

%>

    </table>

    <div class="count">
        Total Orders: <%= orderCount %>
    </div>

    <div class="button-area">

        <a href="newjsp.jsp" class="button">
            Place Another Order
        </a>

        <a href="index.jsp" class="button">
             Home
        </a>

    </div>

</div>

</body>

</html>
